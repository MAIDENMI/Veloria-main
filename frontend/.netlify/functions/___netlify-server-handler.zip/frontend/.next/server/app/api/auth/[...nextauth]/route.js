var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__464055ce._.js")
R.c("server/chunks/[root-of-the-server]__3cc2cf5f._.js")
R.c("server/chunks/[root-of-the-server]__610f16c8._.js")
R.m(14499)
R.m(22398)
module.exports=R.m(22398).exports
