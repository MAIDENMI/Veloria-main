var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chat-voice/route.js")
R.c("server/chunks/[root-of-the-server]__443eb894._.js")
R.c("server/chunks/[root-of-the-server]__610f16c8._.js")
R.c("server/chunks/9e883_next_bb90c88d._.js")
R.m(47323)
R.m(16142)
module.exports=R.m(16142).exports
