var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__2c077f9e._.js")
R.c("server/chunks/9e883_next_dist_esm_build_templates_app-route_bcdfa0bd.js")
R.c("server/chunks/[root-of-the-server]__610f16c8._.js")
R.c("server/chunks/9e883_next_bb90c88d._.js")
R.m(22804)
R.m(49089)
module.exports=R.m(49089).exports
