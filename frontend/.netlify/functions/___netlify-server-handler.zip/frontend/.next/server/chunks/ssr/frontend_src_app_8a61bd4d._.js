module.exports=[27466,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},32017,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(27466).default,width:256,height:256}}];

//# sourceMappingURL=frontend_src_app_8a61bd4d._.js.map