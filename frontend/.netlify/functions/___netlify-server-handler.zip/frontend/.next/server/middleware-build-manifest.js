globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/85446fab15fdabf0.js",
      "static/chunks/8b0aa5ec4afd1278.js",
      "static/chunks/turbopack-e772d0797e25f6d9.js"
    ],
    "/_error": [
      "static/chunks/4bd2471c48f73ed4.js",
      "static/chunks/8b0aa5ec4afd1278.js",
      "static/chunks/turbopack-4cb42e21de0fb21c.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7a1e50b65b8b0e8f.js",
    "static/chunks/ff377072048ded98.js",
    "static/chunks/4e5c27b17d22fe79.js",
    "static/chunks/7bc1410f1004d686.js",
    "static/chunks/9b7b712bde9d32c6.js",
    "static/chunks/turbopack-c5fb98b93d9d4fb8.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];